# Big-clock
## Link instruction
https://www.instructables.com/Big-Digital-Clock-Using-Ws2811-Led-Strip-and-Ardui/

## Demo
![image](https://github.com/user-attachments/assets/539bc4b1-f45e-47e1-bcad-aeef0c8be2e4)
